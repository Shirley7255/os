#include <defs.h>
#include <list.h>
#include <proc.h>
#include <assert.h>
#include <default_sched.h>

static int proc_priority_comp(void *a, void *b)
{
    struct proc_struct *p = le2proc(a, lab6_run_pool);
    struct proc_struct *q = le2proc(b, lab6_run_pool);
    if (p->lab6_priority > q->lab6_priority)
        return -1;
    else if (p->lab6_priority < q->lab6_priority)
        return 1;
    return 0;
}

static void priority_init(struct run_queue *rq)
{
    list_init(&(rq->run_list));
    rq->proc_num = 0;
    rq->lab6_run_pool = NULL;
}

static void priority_enqueue(struct run_queue *rq, struct proc_struct *proc)
{
    if (proc->lab6_priority == 0)
        proc->lab6_priority = 1;
    if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice)
        proc->time_slice = rq->max_time_slice;
    proc->rq = rq;
    /* use skew_heap for efficient selection */
    rq->lab6_run_pool = skew_heap_insert(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_priority_comp);
    rq->proc_num++;
}

static void priority_dequeue(struct run_queue *rq, struct proc_struct *proc)
{
    rq->lab6_run_pool = skew_heap_remove(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_priority_comp);
    proc->rq = NULL;
    rq->proc_num--;
}

static struct proc_struct *priority_pick_next(struct run_queue *rq)
{
    if (rq->lab6_run_pool == NULL)
        return NULL;
    return le2proc(rq->lab6_run_pool, lab6_run_pool);
}

/* priority scheduler: preemption by time-slice like RR */
static void priority_proc_tick(struct run_queue *rq, struct proc_struct *proc)
{
    if (proc->time_slice > 0)
        proc->time_slice--;
    if (proc->time_slice == 0)
        proc->need_resched = 1;
}

struct sched_class priority_sched_class = {
    .name = "PRIORITY_scheduler",
    .init = priority_init,
    .enqueue = priority_enqueue,
    .dequeue = priority_dequeue,
    .pick_next = priority_pick_next,
    .proc_tick = priority_proc_tick,
};
