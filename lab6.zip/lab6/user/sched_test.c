#include <ulib.h>
#include <stdio.h>

/* Set the scheduler id here for each experiment */
/* Force SJF for this test and set bursts explicitly */
#ifndef SCHED_ID
#define SCHED_ID 4
#endif

int main(void)
{
    int bursts[] = {10, 50, 5, 30, 20};
    int n = sizeof(bursts) / sizeof(bursts[0]);
    int pids[10];
    int i;

    /* switch scheduler early to avoid run-queue reinit side-effects */
    lab6_setsched(SCHED_ID);
    const char *sched_name = "unknown";
    switch (SCHED_ID)
    {
    case 0:
        sched_name = "RR";
        break;
    case 1:
        sched_name = "STRIDE";
        break;
    case 2:
        sched_name = "FIFO";
        break;
    case 3:
        sched_name = "SJF";
        break;
    case 4:
        sched_name = "PRIORITY";
        break;
    }
    cprintf("sched_test: set scheduler id %d (%s)\n", SCHED_ID, sched_name);

    for (i = 0; i < n; i++)
    {
        int b = bursts[i];
        int pid = fork();
        if (pid == 0)
        {
            /* set the estimated burst before busy work */
            lab6_setburst(b);
            /* if testing priority scheduler, set a priority (larger value -> more CPU) */
            if (SCHED_ID == 4)
            {
                uint32_t pr = (b >= 100) ? 1 : (100 - b);
                lab6_setpriority(pr);
                cprintf("child %d: set burst=%d priority=%u\n", getpid(), b, pr);
            }
            else
            {
                cprintf("child %d: set burst=%d\n", getpid(), b);
            }
                    unsigned int start = gettime_msec();
                    volatile unsigned long x = 0;
                    unsigned long iters = b * 500000UL;
                    while (iters--)
                    {
                        x += iters & 1;
                    }
            unsigned int end = gettime_msec();
            cprintf("child pid %d burst %d elapsed %u ms\n", getpid(), b, end - start);
            exit(end - start);
        }
        else if (pid > 0)
        {
            pids[i] = pid;
        }
        else
        {
            cprintf("fork failed\n");
        }
    }

    for (i = 0; i < n; i++)
    {
        int status = 0;
        waitpid(pids[i], &status);
        cprintf("parent: child %d status %d\n", pids[i], status);
    }
    cprintf("sched_test done\n");
    return 0;
}
